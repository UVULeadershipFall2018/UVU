//
//  process.cpp
//  Sandbox-classes
//
//  Created by TJ Nielsen on 9/15/18.
//  Copyright © 2018 TJ Nielsen. All rights reserved.
//

#include "process.hpp"

using namespace std;


